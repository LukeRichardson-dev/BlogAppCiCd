# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['blog_server', 'grpc_out']

package_data = \
{'': ['*']}

install_requires = \
['grpcio-tools>=1.44.0,<2.0.0', 'grpcio>=1.44.0,<2.0.0']

entry_points = \
{'console_scripts': ['run-blog = blog_server.main:main']}

setup_kwargs = {
    'name': 'blog',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'lukerichardson-dev',
    'author_email': 'richardsonluke232@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
